Conky Elegant Rings

I would like to acknowledge the following authors in providing the material to create this Conky:

abuyahya for the Revolutionary Clock: http://gnome-look.org/content/show.php/Revolutionary+Clock+%28+Conky+%29?content=151215
Yirt for some of the code in Conky CPU-MEM-NET: http://gnome-look.org/content/show.php/Conky+CPU-MEM-NET?content=158074
Hardba11 for code from Conky_Grey Blue Variation: http://gnome-look.org/content/show.php/conky_grey+blue+variation?content=154952

I borrowed & changed from all three sources to create Elegant Rings---THANK ALL OF YOU!!!

The lua script is explained in the conky_elegant_rings.txt file.

To install just move or copy the " .Conky " hidden folder to your user/home folder!

Don't forget to install the fonts!

to run, execute ' conky-startup.sh '

To enable conky to start with the system go to " startup applications " and add in the " command " the file " .Conky/conky-startup.sh "

  

