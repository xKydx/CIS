#!/bin/bash
conky -c ~/.conky/conkyrc_elegant_rings ;
