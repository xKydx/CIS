#!/bin/sh
conky -c ~/.conkyrc;
conky -c ~/.conkyrc2
conky -c ~/.conkyrc3
conky -c ~/.conkyrc4
conky -c ~/.conkyrc5
