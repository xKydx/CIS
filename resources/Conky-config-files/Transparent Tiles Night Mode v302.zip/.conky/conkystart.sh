#!/bin/bash
sleep 30 &
conky -c ~/.conky/time &
sleep 3 &
conky -c ~/.conky/systemstat &
sleep 3 &
conky -c ~/.conky/weather_now &
sleep 3 &
conky -c ~/.conky/weather_forecast &
sleep 3 &
conky -c ~/.conky/news &
sleep 3 &
conky -c ~/.conky/webupd8 &
exit 0
