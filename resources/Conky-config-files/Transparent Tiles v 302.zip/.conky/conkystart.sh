#!/bin/bash
sleep 30 &
conky -c ~/.conky/time &
sleep 5 &
conky -c ~/.conky/systemstat &
sleep 5 &
conky -c ~/.conky/weather_now &
sleep 5 &
conky -c ~/.conky/weather_forecast &
sleep 5 &
conky -c ~/.conky/news &
sleep 5 &
conky -c ~/.conky/webupd8 &
exit 0
