#!/bin/bash
sleep 15
conky -c ~/.conkyrc 
