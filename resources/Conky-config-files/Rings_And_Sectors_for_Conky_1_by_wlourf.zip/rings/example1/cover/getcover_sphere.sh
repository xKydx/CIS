#!/bin/bash
# by larryni
# get Amarok cover art of current track and transform into an album stack
# copypasta from http://www.imagemagick.org/Usage/mapping/#spherical
# thanks to eightmillion for rewriting the original script
# http://ubuntuforums.org/showpost.php?p=8117609&postcount=9846

# Temp directory must be full path.
tempdir="$HOME/conky/rings/example1/cover/"
tempfile="${tempdir}nowplaying"

[ -d "$tempdir" ] || mkdir -p "$tempdir"  #test if $tempdir exists, if not create it.
[ -e "$tempfile" ] || touch "$tempfile"

cover="$(dcop amarok player coverImage)"
[ -z "$cover" ] && exit      #test if $cover was set, if not exit.

hash=$(echo "$cover" | md5sum | cut -d" " -f 1) #Generate hash for current song.

read oldhash < "$tempfile"

if [ "$oldhash" == "$hash" ];then
        :
else
	convert ${cover} -resize 75x75! "${tempdir}sphere_overlay.png" -compose HardLight -composite "${tempdir}sphere_mask.png" -alpha off -compose CopyOpacity -composite "${tempdir}cover_sphere.png"
   echo $hash > "$tempfile"
fi
exit
